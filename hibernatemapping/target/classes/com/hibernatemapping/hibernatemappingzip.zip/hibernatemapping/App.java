package com.hibernatemapping.hibernatemapping;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	List<Question> li1=new ArrayList<Question>();
    	SessionFactory factory= new Configuration().configure().buildSessionFactory();
    	Session ses=factory.openSession();
    	Transaction tx=ses.beginTransaction();
    	Question q=new Question();
    	/*q.setId(25);
    	q.setQ_name("What is JRE");
    	Answer a=new Answer();
    	a.setA_id(505);
    	a.setA_solution("Java Runtime Environment");
    	q.setA_id(a);
    	ses.save(q);
    	ses.save(a);
    	System.out.println("Added");*/
    	List<?> q1=ses.createQuery("from Question").list();
    	for(Iterator<?> it=q1.iterator();it.hasNext();)
    	{
    		Question qu=(Question) it.next();
    		System.out.println("Q -"+qu.getId()+" : "+qu.getQ_name());
    		Answer an=(Answer)qu.getA_id();
    		System.out.println("A-"+an.getA_id()+ " :"+an.getA_solution());
    	}
    	tx.commit();
    	ses.close();
    	factory.close();
    }
}
